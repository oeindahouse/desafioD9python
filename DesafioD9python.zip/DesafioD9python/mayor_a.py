def filtrarBalance(meses, umbral):
    # función filtrado de ingresos
    ingresosFiltrados = {mes: ingreso for mes, ingreso in meses.items() if ingreso > umbral}
    return ingresosFiltrados

# lista de datos de balance por mes
balances = {
    "Enero": 15000,
    "Febrero": 22000,
    "Marzo": 12000,
    "Abril": 17000,
    "Mayo": 81000,
    "Junio": 13000,
    "Julio": 21000,
    "Agosto": 41200,
    "Septiembre": 25000,
    "Octubre": 21500,
    "Noviembre": 91000,
    "Diciembre": 21000,
}

# ingresar el umbral deseado
umbralDeseado = int(input("ingrese el valor del umbral deseado: "))

#función para filtrar los ingresos
resultadosFiltrados = filtrarBalance(balances, umbralDeseado)

print(f"\nIngresos que superan el umbral: {umbralDeseado}:")
for mes, ingreso in resultadosFiltrados.items():
    print(f"{mes}: {ingreso}")

