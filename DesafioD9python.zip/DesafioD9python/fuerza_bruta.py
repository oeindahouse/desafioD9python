#importar string con todas las letras del abecedario en minúsculas (sin la ñ)
from string import ascii_lowercase

#def funcion
def fuerza_bruta():
    #mi pass dada
    contrasena = str(input("Ingrese el password: ")).lower()
    #pass que se generara y comparara
    contrasenaGenerada = ''
    #n° veces que el modelo intenta dar con la pass dada, empieza en 0
    intento = 0
    #iteracion con la funcion enumerate sobre la cadena de password, par la busqueda de la pass generada
    for i, _ in enumerate(contrasena):
        #recorrer con el diccionario ascii
        for letra in ascii_lowercase:
            #por cada iteracion se suma uno, sea o no valido
            intento += 1
            #si coinciden, se guarda la letra y genera la nva pass
            if letra == contrasena[i]:
                contrasenaGenerada += letra
                break
    #imprimir la cantidad de intentos para calzar ambas pass
    print(f"\nLa contrasena fue forzada en: {intento} intentos")


fuerza_bruta()


