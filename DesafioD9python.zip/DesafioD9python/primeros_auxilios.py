print ("-----**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-----")
print ("-----**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-----")

print ("Valores válidos: *s* para SÍ y *n* para NO")

respuesta = ["s","n"] 

def primerosAuxilios():
    while True:
        respondeEstimulos = str(input("¿La persona responde a estímulos?: ")).lower()
        if respondeEstimulos in respuesta:
            if respondeEstimulos == "s":
                print("Valorar la necesidad de llevarlo al hospital más cercano")
                break
            else:
                print("Abrir la vía Aérea")
                respira = str(input("¿Respira?: ")).lower()
                if respira in respuesta:
                    if respira == "s":
                        print("Permitirle posición de suficiente ventilación")
                        break
                    else:
                        print("Administrar 5 Ventilaciones y llamar a Ambulancia")
                        signosVida = str(input("¿Signos de vida?")).lower()
                        if signosVida in respira:
                            if signosVida == "s":
                                print("Reevaluar a la espera de la Ambulancia")
                            else:
                                print("Administrar Compresiones Torácicas hasta que llegue ambulancia")
                            llegoAmbulancia = str(input("¿Llegó la ambulancia?")).lower()
                            if llegoAmbulancia in respira:
                                if llegoAmbulancia == "s":
                                    break
                                else:
                                    print("ingrese respuesta válida")
                            else:
                                print("ingrese respuesta válida")
                        else:
                            print("ingrese respuesta válida")
                else:
                    print("ingrese respuesta válida")
        else:
            print("ingrese respuesta válida")
    print("Fin")
primerosAuxilios()
print ("-----**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-----")
print ("-----**-**-**-**-**-**-**-**-**-**-**-**-**-**-**-----")